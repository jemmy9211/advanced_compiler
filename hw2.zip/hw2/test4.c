#include <stdio.h>

void foo( )
{ 
	int a,b,c,d,e,x,y,f,g,h,i; 
	int *p; 
	a = b +c; 
	p = &y; 
	d = b + c; 
	f = a + d + x +y; 
	g = a + d + x +y; 
	*p = i + 2; 
	h = a + d + x +y; 
	f = y + 1; 
}